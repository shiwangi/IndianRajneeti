package com.example.indianRajneeti;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class PoliticianNews extends Activity {

    String names[] = {"Mamta Bannerjee", "Sonia Gandhi", "Narendra Modi", "Manmohan Singh", "Rahul Gandhi", "Arvind Kejriwal"
    };
    String filter[][] = {
            {"mamata", "mamta", "trinamool", "tmc", "bengal", "bannerjee"},
            {"congress", "upa", "sonia", "gandhi", "chairperson", "rajiv"},
            {"bjp", "modi", "gujarat", "narendra", "godhra", "keshubai"},
            {"manmohan", "pm", "singh", "pmo", "government", "sardar"},
            {"rahul", "gandhi", "congress", "pm", "rahul", "rahul"},
            {"arvind", "kejriwal", "aap", "delhi", "aam", "aadmi"}};

    int index;
    List<String> newsUrl = new ArrayList<String>();
    List<String> newsHyperlinks = new ArrayList<String>();

    PoliticianAdapter netaDalAdapter;

    String netaName;
    ImageView netaImg;
    TextView netaTitle;

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);

        overridePendingTransition(R.anim.slideright, R.anim.slideright2);

        setContentView(R.layout.activity_news);
        Bundle gotBasket = getIntent().getExtras();
        netaName = gotBasket.getString("name");
        index = Integer.parseInt(gotBasket.getString("index"));

        initialize();

        String icon = "drawable/" + netaName;
        int resID = getResources().getIdentifier(icon, null, getPackageName());
        Drawable image = getResources().getDrawable(resID);
        netaImg.setImageDrawable(image);

        listView = (ListView) findViewById(R.id.listNews);
        netaDalAdapter = new PoliticianAdapter(PoliticianNews.this, newsUrl);

        Thread downloadThread = new Thread() {
            public void run() {
                Document doc;
                try {

                    doc = Jsoup.connect("http://www.rediff.com/news/headlines")
                            .get();
                    final Elements links = doc.select("a[href]");

                    runOnUiThread(new Runnable() {

                        public void run() {

                            for (Element link : links) {
                                String l1 = String.format("%s", link.text());
                                String l2 = String.format("%s",
                                        link.attr("abs:href"));

                                if (l1.length() >= 30) {
                                    int i;
                                    for (i = 0; i < 6; i++) {
                                        String search = l1.toLowerCase();
                                        if (search
                                                .contains(filter[index][i])) {
                                            newsUrl.add(l1);
                                            newsHyperlinks.add(l2);
                                        }
                                    }
                                }
                                netaDalAdapter.add(newsUrl);
                                listView.setAdapter(netaDalAdapter);
                            }

                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };

        downloadThread.start();

        listView.setOnItemClickListener(new OnItemClickListener() {

            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                String url = newsHyperlinks.get(position);
                Bundle basket = new Bundle();
                basket.putString("key", url);
                Intent a = new Intent(PoliticianNews.this, NewsPage.class);
                a.putExtras(basket);
                startActivity(a);

            }

        });
    }

    private void initialize() {
        // TODO Auto-generated method stub
        netaTitle = (TextView) findViewById(R.id.tvParty);
        netaTitle.setText(names[index]);

        netaImg = (ImageView) findViewById(R.id.imgParty);
    }

}

package com.example.indianRajneeti;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class PartyNews extends Activity {

    TextView resources, partyName;
    List<String> newsUrl = new ArrayList<String>();
    List<String> newsHyperLinks = new ArrayList<String>();
    LinearLayout viewLayout;
    ImageView imageParty;
    String politicalPartyName;
    String title;
    NetaDalAdapter partyAdapterObj;
    int index;

    String filterDetails[][] = {{"congress", "upa", "sonia", "gandhi", "rahul", "pm ", "manmohan", "chidambaram", "shinde", "pranab"},
            {"bjp", "modi", "sushma", "jaitley", "gujarat", "advani", "vajpayee", "joshi", "nda", "moily"},
            {"samajwadi", "mulayam", "akhilesh", "yadav", "up ", "kalyan", "sp ", "uttar pradesh", "mohan", "sp "},
            {"bsp", "maya", "mayawati", "dalit", "up ", "uttar pradesh", "bahujan", "kanshi", "ambedkar", "statue"},
            {"aap", "arvind", "kejriwal", "aap", "kumar vishwas", "delhi cm", "aam", "aadmi", "party", "arvind"}};

    @SuppressWarnings("deprecation")
    @Override


    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.slideleft, R.anim.slideleft2);
        setContentView(R.layout.activity_news);
        Bundle gotBasket = getIntent().getExtras();
        politicalPartyName = gotBasket.getString("party");
        title = gotBasket.getString("title");
        index = Integer.parseInt(gotBasket.getString("index"));
        resources = (TextView) findViewById(R.id.tvNews);
        viewLayout = (LinearLayout) findViewById(R.id.layoutparty);
        partyName = (TextView) findViewById(R.id.tvParty);
        imageParty = (ImageView) findViewById(R.id.imgParty);

        partyName.setText(title);

        String icon = "drawable/" + politicalPartyName + "image";
        int resID = getResources().getIdentifier(icon, null, getPackageName());
        Drawable image = getResources().getDrawable(resID);
        imageParty.setImageDrawable(image);

        String bgicon = "drawable/" + politicalPartyName + "bg";
        int ID = getResources().getIdentifier(bgicon, null, getPackageName());
        Drawable bgimage = getResources().getDrawable(ID);
        viewLayout.setBackgroundDrawable(bgimage);

        final ListView lv = (ListView) findViewById(R.id.listNews);
        partyAdapterObj = new NetaDalAdapter(PartyNews.this, newsUrl);

        lv.setAdapter(partyAdapterObj);

        lv.setOnItemClickListener(new OnItemClickListener() {


            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String url = newsHyperLinks.get(position);
                Bundle basket = new Bundle();
                basket.putString("key", url);
                Intent a = new Intent(PartyNews.this, NewsPage.class);
                a.putExtras(basket);
                startActivity(a);

            }


        });

        Thread downloadThread = new Thread() {
            @SuppressWarnings("unused")
            public void run() {
                Document doc;
                try {

                    doc = Jsoup.connect("http://www.rediff.com/news/headlines").get();
                    final String title = doc.title();
                    final Elements links = doc.select("a[href]");


                    runOnUiThread(new Runnable() {

                        public void run() {

                            for (Element link : links) {
                                String l1 = String.format("%s", link.text());
                                String l2 = String.format("%s", link.attr("abs:href"));

                                if (l1.length() >= 30) {
                                    int i;
                                    for (i = 0; i < 10; i++) {
                                        String search = l1.toLowerCase();
                                        if (search.contains(filterDetails[index - 1][i])) {
                                            newsUrl.add(l1);
                                            newsHyperLinks.add(l2);
                                        }
                                    }
                                }
                                partyAdapterObj.add(newsUrl);
                                lv.setAdapter(partyAdapterObj);
                            }


                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };

        downloadThread.start();
    }


}
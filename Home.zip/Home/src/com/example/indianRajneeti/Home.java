package com.example.indianRajneeti;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.TextView;

public class Home extends Activity implements OnClickListener, OnTouchListener {

    TextView parties, netas, personalisedPaper, newspapers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homepage);
        initialize();
    }

    private void initialize() {
        // TODO Auto-generated method stub
        parties = (TextView) findViewById(R.id.tvParties);
        netas = (TextView) findViewById(R.id.tvPoliticians);
        personalisedPaper = (TextView) findViewById(R.id.tvMyPaper);
        newspapers = (TextView) findViewById(R.id.tvPapers);

        netas.setOnTouchListener(this);
        parties.setOnTouchListener(this);
        personalisedPaper.setOnTouchListener(this);
        newspapers.setOnTouchListener(this);

    }

    public void onClick(View v) {

    }

    @Override
    protected void onActivityResult(int reqCode, int resultCode, Intent data) {
        // TODO Auto-generated method stub
        super.onActivityResult(reqCode, resultCode, data);
        if (reqCode == 0) {
            overridePendingTransition(R.anim.slideleft, R.anim.slideleft2);
        } else {
            overridePendingTransition(R.anim.slideright, R.anim.slideright2);
        }
    }

    @SuppressWarnings("deprecation")
    public boolean onTouch(View view, MotionEvent event) {
        switch (view.getId()) {
            case R.id.tvMyPaper:
                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        ((TextView) view).setTextColor(0xFF000006);
                        Drawable background = getResources().getDrawable(
                                R.drawable.style);
                        view.setBackgroundDrawable(background);
                        Intent i3 = new Intent(Home.this, PersonalPaper.class);
                        startActivityForResult(i3, 0);
                        break;
                }
                break;

            case R.id.tvPapers:
                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        Drawable background = getResources().getDrawable(
                                R.drawable.style);
                        view.setBackgroundDrawable(background);
                        Intent i2 = new Intent(Home.this, PersonalPaper.class);
                        startActivityForResult(i2, 1);
                        break;
                }
                break;

            case R.id.tvPoliticians:
                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        Drawable background = getResources().getDrawable(
                                R.drawable.style);
                        (view).setBackgroundDrawable(background);
                        Intent i = new Intent(Home.this, Politician.class);
                        startActivity(i);
                        break;
                }
                break;

            case R.id.tvParties:
                switch (event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        Drawable background = getResources().getDrawable(
                                R.drawable.style);
                        view.setBackgroundDrawable(background);
                        Intent i1 = new Intent(Home.this, NetaDal.class);
                        startActivityForResult(i1, 1);
                        break;
                }
                break;

        }
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }

}

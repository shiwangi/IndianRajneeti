package com.example.indianRajneeti;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import android.app.Activity;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class PersonalPaper extends Activity {

    String filterKey[];
    String filterDetails[][] = {
            {"congress", "upa", "sonia", "gandhi", "rahul", "pm ",
                    "manmohan",
                    "chidambaram", "shinde", "pranab"},
            {"bjp", "vajpayee", "joshi", "nda", "modi", "sushma", "jaitley", "gujarat", "advani",
                    "moily"},
            {"samajwadi", "mulayam", "sp ", "uttar pradesh", "mohan",
                    "akhilesh", "yadav", "up ", "kalyan"
                    , "sp "},
            {"bsp", "bahujan", "kanshi", "ambedkar", "statue",
                    "maya", "mayawati", "dalit", "up ", "uttar pradesh",
                    },
            {"aap", "arvind", "kejriwal", "jhaadu", "delhi",
                    "aam", "aadmi", "topi", "Bhagwant", "cm"}
    };

    List<String> newsLinks = new ArrayList<String>();
    List<String> newsURLs = new ArrayList<String>();

    MyPaperAdapter paperEnhancer;

    ListView listView;
    Button editsubs;

    TextView name;
    ImageView image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);

        overridePendingTransition(R.anim.slideright, R.anim.slideright2);

        setContentView(R.layout.mypaper);

        init();
        populatefilterDetails();

        listView = (ListView) findViewById(R.id.listNews);
        paperEnhancer = new MyPaperAdapter(PersonalPaper.this, newsLinks);

        Thread threadDownload = new Thread() {
            public void run() {
                Document doc;
                try {

                    doc = Jsoup.connect("http://www.rediff.com/news/headlines")
                            .get();
                    final Elements links = doc.select("a[href]");

                    runOnUiThread(new Runnable() {

                        public void run() {

                            for (Element link : links) {
                                String l1 = String.format("%s", link.text());
                                String l2 = String.format("%s",
                                        link.attr("abs:href"));

                                if (l1.length() >= 30) {

                                    int i, j;
                                    boolean match = false;

                                    for (i = 0; i < 5; i++) {
                                        String search = l1.toLowerCase();

                                        for (j = 0; j < filterKey.length; j++)
                                            if (filterDetails[i][0]
                                                    .equalsIgnoreCase(filterKey[j])) {

                                                match = true;
                                                break;
                                            }
                                        if (match) {
                                            if (l1.length() >= 30) {
                                                int k;
                                                for (k = 0; k < 10; k++) {

                                                    if (search
                                                            .contains(filterDetails[i][k])) {
                                                        newsLinks.add(l1);
                                                        newsURLs.add(l2);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    paperEnhancer.add(newsLinks);
                                    listView.setAdapter(paperEnhancer);
                                }
                            }
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };

        threadDownload.start();

        listView.setOnItemClickListener(new OnItemClickListener() {

            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                String url = newsURLs.get(position);
                Bundle basket = new Bundle();
                basket.putString("key", url);

                Intent a = new Intent(PersonalPaper.this, NewsPage.class);
                a.putExtras(basket);
                startActivity(a);

            }

        });
    }

    private void populatefilterDetails() {
        // TODO Auto-generated method stub
        StoredPreference info = new StoredPreference(this);
        info.open();
        String data = info.getfilter();
        filterKey = data.split(System.getProperty("line.separator"));
        info.close();
    }

    private void init() {
        // TODO Auto-generated method stub
        name = (TextView) findViewById(R.id.tvParty);
        image = (ImageView) findViewById(R.id.imgParty);
        name.setText("Personalised Paper");
        editsubs = (Button) findViewById(R.id.bEditSubs);
        editsubs.setOnClickListener(new OnClickListener() {

            public void onClick(View v) {
                Intent i = new Intent(PersonalPaper.this, MyPaperInstruct.class);
                startActivity(i);
            }
        });

        int resID = getResources().getIdentifier("drawable/launcher", null,
                getPackageName());
        Drawable image = getResources().getDrawable(resID);
        this.image.setImageDrawable(image);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }
}
